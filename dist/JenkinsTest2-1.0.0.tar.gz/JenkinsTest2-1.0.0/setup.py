from setuptools import setup, find_packages

setup(
    name='JenkinsTest2',
    version='1.0.0',
    packages=find_packages(),
    author='Antonio Rodilosso',
    author_email='antonio.rodilosso@iet.it',
    description='Breve descrizione del tuo progetto',
    url='https://github.com/antoniorodilosso23/JenkinsTest2',
    install_requires=[
        # Dipendenze del tuo progetto
    ],
)